/*
 * Copyright (c) 2026 Mark S. Kolich
 * https://mark.koli.ch
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

package curacao.mcp.prompts;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Preconditions.checkState;

/**
 * An argument a prompt accepts, advertised in {@code prompts/list} so clients can ask the user
 * for it.
 */
@JsonPropertyOrder({"name", "description", "required"})
public interface McpPromptArgument {

    @JsonProperty("name")
    String getName();

    @Nullable
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty("description")
    String getDescription();

    @JsonProperty("required")
    boolean isRequired();

    final class Builder {

        private String name_;
        private String description_;
        private boolean required_;

        public Builder setName(
                @Nonnull final String name) {
            name_ = checkNotNull(name, "Argument name cannot be null.");
            return this;
        }

        public Builder setDescription(
                @Nullable final String description) {
            description_ = description;
            return this;
        }

        /**
         * Whether every {@code prompts/get} must include the argument; the server rejects a request without it.
         * Defaults to false.
         */
        public Builder setRequired(
                final boolean required) {
            required_ = required;
            return this;
        }

        /**
         * Builds the argument.
         *
         * @throws IllegalStateException if no name was set
         */
        public McpPromptArgument build() {
            checkState(name_ != null, "A prompt argument needs a name.");

            return new McpPromptArgument() {
                @Override
                public String getName() {
                    return name_;
                }

                @Override
                public String getDescription() {
                    return description_;
                }

                @Override
                public boolean isRequired() {
                    return required_;
                }
            };
        }

    }

}
